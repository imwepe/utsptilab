// Set up variables
let points = 0;
let clickMultiplier = 10000;
let autoclickpoints = 1000;
let autoClickerRate = 1000; // in milliseconds
const hargaTahu = 100000;
const hargaRisol = 200000;
const hargaCakwe = 300000;

let autoTahu = 1000000;
let multiTahu = 1000000;
let autoRisol = 2000000;
let multiRisol = 2500000;
let autoCakwe = 3000000;
let multiCakwe = 4000000;
let autoTahuIsi = 500000;
let priceAuto = 1000;
let x = 1;
let TF = 0;
let TFTI = 0;
let TFR = 0;
let TFC = 0;

function showPopup() {
  document.getElementById("popup").style.visibility = "visible";
}
function hidePopup() {
  document.getElementById("popup").style.visibility = "hidden";
}

document.getElementById("T").addEventListener("click", function() {
  points = points + 10000*x;
  document.getElementById("points").innerHTML = points;
});

document.getElementById("TI").addEventListener("click", function() {
  points = points + 30000*x;
  document.getElementById("points").innerHTML = points;
});

document.getElementById("R").addEventListener("click", function() {
  points = points + 50000*x;
  document.getElementById("points").innerHTML = points;
});

document.getElementById("C").addEventListener("click", function() {
  points = points + 75000*x;
  document.getElementById("points").innerHTML = points;
});

document.getElementById("tahu").addEventListener("click",function(){
    if(points < (hargaTahu-1)){
      alert("Duit Tidak Cukup");
    } 
    else {
      points -= hargaTahu;
      clickMultiplier += hargaTahu;
      document.getElementById("jualTahu").style.visibility = "hidden";
      document.getElementById("points").innerHTML = points;
      document.getElementById("tahuisi").style.visibility = "visible";
    }
  });

  document.getElementById("risol").addEventListener("click",function(){
    if(points < (hargaRisol-1)){
      alert("Duit Tidak Cukup");
    } 
    else {
      points -= hargaRisol;
      clickMultiplier += hargaRisol;
      document.getElementById("jualRisol").style.visibility = "hidden";
      document.getElementById("points").innerHTML = points;
      document.getElementById("risol2").style.visibility = "visible";
    }
  });
  document.getElementById("cakwe").addEventListener("click",function(){
    if(points < (hargaCakwe-1)){
      alert("Duit Tidak Cukup");
    } 
    else {
      points -= hargaCakwe;
      clickMultiplier += hargaCakwe;
      document.getElementById("jualCakwe").style.visibility = "hidden";
      document.getElementById("points").innerHTML = points;
      document.getElementById("cakwe2").style.visibility = "visible";
    }
  });
  

//Auto tahu
document.getElementById("autoClick").addEventListener("click", function() {
    document.getElementById("priceAuto").innerHTML = priceAuto;
      if (TF < 5){
        if(points < (priceAuto-1)){
          alert("Duit Tidak Cukup");
        }else {
          points -= priceAuto;
          document.getElementById("points").innerHTML = points;
          priceAuto += 5000;
          document.getElementById("priceAuto").innerHTML = priceAuto;
          setInterval(function(){
            points += autoclickpoints;
            document.getElementById("points").innerHTML = points;
          }, autoClickerRate)
        }
        TF++;
      }
      else if(TF >= 5){
        document.getElementById("autoClick").style.visibility = "hidden";
        document.getElementById("CostautoT").style.visibility = "hidden";
      }
    });

    //Auto tahu isi
    document.getElementById("autoTI").addEventListener("click", function() {
      document.getElementById("priceTI").innerHTML = autoTahuIsi;
        if (TFTI < 5){
          if(points < (autoTahuIsi-1)){
            alert("Duit Tidak Cukup");
          }else {
            points -= autoTahu;
            document.getElementById("points").innerHTML = points;
            autoTahuIsi += 100000;
            document.getElementById("priceTI").innerHTML = autoTahuIsi;
            setInterval(function(){
              points += autoclickpoints;
              document.getElementById("points").innerHTML = points;
            }, autoClickerRate)
          }
          TFTI++;
        }
        else if(TFTI >= 5){
          document.getElementById("autoTI").style.visibility = "hidden";
          document.getElementById("CostautoTI").style.visibility = "hidden";
        }
      });

    //Auto risol
    document.getElementById("autoR").addEventListener("click", function() {
      document.getElementById("priceR").innerHTML = autoRisol;
        if (TFR < 5){
          if(points < (autoRisol-1)){
            alert("Duit Tidak Cukup");
          }else {
            points -= autoRisol;
            document.getElementById("points").innerHTML = points;
            autoRisol += 250000;
            document.getElementById("priceR").innerHTML = autoRisol;
            setInterval(function(){
              points += autoclickpoints;
              document.getElementById("points").innerHTML = points;
            }, autoClickerRate)
          }
          TFR++;
        }
        else if(TFR >= 5){
          document.getElementById("autoR").style.visibility = "hidden";
          document.getElementById("CostautoR").style.visibility = "hidden";
        }
      });


    //Auto cakwe
    document.getElementById("autoC").addEventListener("click", function() {
      document.getElementById("priceC").innerHTML = autoCakwe;
        if (TFC < 5){
          if(points < (autoCakwe-1)){
            alert("Duit Tidak Cukup");
          }else {
            points -= autoCakwe;
            document.getElementById("points").innerHTML = points;
            autoCakwe += 500000;
            document.getElementById("priceC").innerHTML = autoCakwe;
            setInterval(function(){
              points += autoclickpoints;
              document.getElementById("points").innerHTML = points;
            }, autoClickerRate)
          }
          TFC++;
        }
        else if(TFC >= 5){
          document.getElementById("autoC").style.visibility = "hidden";
          document.getElementById("CostautoC").style.visibility = "hidden";
        }
      });
    
    // MULTIPLIER
    /*// document.getElementById("multiple").addEventListener("click", function() {
    // if (points < (1000-1)){
    //   alert("Duit Tidak Mencukupi");
    // }else if(points > (1000-1)){
    //     if(x <= 5){
    //       x += 1;
    //     }else if(x >= 5){
    //       document.getElementById("multi").style.visibility = "hidden";    
    //   }
    //   points -= 1000;
    //   document.getElementById("points").innerHTML = points;
    //     }
    // });*/

    // function addImage() {
    //   // create a new image element
    //   var img = document.createElement('img');
    //   // set the image source
    //   img.src = '';
    //   // append the image to the image container
    //   document.getElementById('jualTahu').appendChild(img);
    //   document.getElementById('jualRisol').appendChild(img);
    //   document.getElementById('jualCakwe').appendChild(img);
    // }




//bikin js buat tahu (sekali klik nambah lebih banyak), auto(lebih banyak, lebih mahal), multi (sama, lebih mahal);


//copas ini tahu
 document.getElementById("multiT").addEventListener("click", function() {
   if (points < (500000))
   {
     alert("Duit Tidak Mencukupi");
   }
   else if(points >= (500000))
   {
    if(x <= 5){
         x++;
       }else if(x >= 5)
       {
         document.getElementById("multiT").style.visibility = "hidden";    
      }
     points -= 500000;
     document.getElementById("points").innerHTML = points;
       }
   });

   document.getElementById("multiTI").addEventListener("click", function() {
    if (points < (500000))
    {
      alert("Duit Tidak Mencukupi");
    }
    else if(points >= (500000))
    {
     if(x <= 5){
          x++;
        }else if(x >= 5)
        {
          document.getElementById("multiTI").style.visibility = "hidden";    
       }
      points -= 500000;
      document.getElementById("points").innerHTML = points;
        }
    });

    document.getElementById("multiR").addEventListener("click", function() {
      if (points < (500000))
      {
        alert("Duit Tidak Mencukupi");
      }
      else if(points >= (500000))
      {
       if(x <= 5){
            x++;
          }else if(x >= 5)
          {
            document.getElementById("multiR").style.visibility = "hidden";    
         }
        points -= 500000;
        document.getElementById("points").innerHTML = points;
          }
      });

      document.getElementById("multiC").addEventListener("click", function() {
        if (points < (500000))
        {
          alert("Duit Tidak Mencukupi");
        }
        else if(points >= (500000))
        {
         if(x <= 5){
              x++;
            }else if(x >= 5)
            {
              document.getElementById("multiC").style.visibility = "hidden";    
           }
          points -= 500000;
          document.getElementById("points").innerHTML = points;
            }
        });